# LaunchPad v1.0.0
### Your personal career command center

## Deploy to Netlify (5 minutes)

### Option A — Netlify Drop (fastest, no account needed)
1. Go to **netlify.com/drop**
2. Drag and drop the entire `launchpad` folder onto the page
3. Get a live URL instantly (e.g. `amazing-name-123.netlify.app`)
4. Open it on any device — API calls work from a real URL

### Option B — Netlify with account (for auto-updates)
1. Create a free account at **netlify.com**
2. Click "Add new site" → "Deploy manually"
3. Drag the folder in
4. Go to Site Settings → Change site name → set to `launchpad-app`
   (this makes your version check URL work: `launchpad-app.netlify.app/version.json`)

## Publishing updates
1. Edit `launchpad_live.html`
2. Update `"version"` in `version.json` (e.g. `"1.0.1"`)
3. Add a note to `"notes"` describing what changed
4. Re-drag the folder to Netlify
5. All users will see the update banner within seconds of opening the app

## Files in this folder
- `launchpad_live.html` — the full app (single file)
- `version.json` — version manifest for auto-update checks
- `netlify.toml` — Netlify configuration
- `README.md` — this file

## Local testing (if you need the API without hosting)
```bash
# Python (if installed)
cd this-folder
python3 -m http.server 8080
# Open localhost:8080 in browser

# Node (if installed)
npx serve .
# Open the URL shown
```

## API setup
The app uses the Anthropic API for:
- CareerHelpAI career coach
- Resume tailoring with diff view
- Interview prep guide generation
- Dynamic promotion path ratings
- Salary negotiation scripts

No API key setup needed — the app handles this automatically when
accessed from claude.ai or a hosted URL.

---
Built with LaunchPad · v1.0.0
